from flask import Flask, render_template, request, jsonify, redirect, url_for
import mysql.connector
from datetime import datetime

app = Flask(__name__)

# Configurações da sua conexão com o MySQL
# Lembre-se de alterar 'SUA_SENHA' para a senha do seu banco de dados
def get_db_connection():
    return mysql.connector.connect(
        host='200.131.251.11',
        user='2026Hack',
        password='Hack@2026', 
        database='2026ProjetoHack'
    )

# 1. ROTA PARA CARREGAR A PÁGINA DE DESBLOQUEIO
@app.route('/admin/desbloqueio')
def index():
    return render_template('admin_desbloqueio.html')

# 2. MECANISMO DE BUSCA (AÇÃO DO BOTÃO AMARELO)
# Esta rota é chamada pelo JavaScript sem recarregar a página
@app.route('/api/buscar-ip-bloqueado', methods=['POST'])
def buscar_ip():
    dados = request.get_json()
    id_usuario = dados.get('id_usuario')
    
    if not id_usuario:
        return jsonify({'error': 'ID não fornecido'}), 400

    conn = get_db_connection() # SERVIDOR DO BANCO DE DADOS
    cursor = conn.cursor(dictionary=True)

    # Query SQL baseada na estrutura das suas tabelas 'bloqueio' e 'login'
    # Busca o IP e o Motivo original do último bloqueio deste usuário
    query = """
        SELECT l.ip_origem, b.num_bloqueio, b.motivo 
        FROM bloqueio b
        JOIN login l ON b.num_tentativa = l.num_tentativa
        WHERE l.num_usuario = %s
        ORDER BY b.data DESC LIMIT 1
    """
    
    cursor.execute(query, (id_usuario,))
    resultado = cursor.fetchone()
    
    cursor.close()
    conn.close()

    if resultado:
        return jsonify({
            'ip': resultado['ip_origem'],
            'num_bloqueio': resultado['num_bloqueio'],
            'motivo_original': resultado['motivo']
        })
    else:
        return jsonify({'error': 'Nenhum bloqueio encontrado para este ID'}), 404

# 3. ROTA PARA EFETIVAR O DESBLOQUEIO (BOTÃO FINAL)
@app.route('/processar-desbloqueio', methods=['POST'])
def processar_desbloqueio():
    # Coleta os dados do formulário
    id_usuario = request.form.get('id_usuario')
    num_bloqueio = request.form.get('num_bloqueio_input') # Campo oculto com o ID do bloqueio
    motivo_admin = request.form.get('motivo_desbloqueio')
    
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Registra o desbloqueio na tabela 'desbloqueio'
        # usuario_responsavel '1' simula o ID do Admin logado
        sql = """
            INSERT INTO desbloqueio (data, usuario_responsavel, num_bloqueio)
            VALUES (%s, %s, %s)
        """
        cursor.execute(sql, (datetime.now(), 1, num_bloqueio))
        conn.commit()
        
        return "<h1>Sucesso! Usuário desbloqueado.</h1><a href='/admin/desbloqueio'>Voltar</a>"
    except Exception as e:
        return f"<h1>Erro ao processar: {e}</h1>"
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    # Roda o servidor em modo de depuração na porta 5000
    app.run(debug=True)